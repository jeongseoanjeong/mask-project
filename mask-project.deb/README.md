# mask-project
uv sterilizer for raspberry pi!(open-source! free to use/modify)
# OS
works best in raspbian.

# what do i need
this program works best on gnome-terminal.(to use --maximize option)

# how do i use this?
to see how to use, go to https://www.instructables.com/Raspberry-Pi-Mask-Sterilizer-include-Open-source-S/
# license
BSD license so you can free to use/modify!
